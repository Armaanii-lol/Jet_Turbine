using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ToggleMethod : MonoBehaviour
{
    public GameObject mopedComponent;
    private bool isVisible = true;
    public void Toggle()
    {
        if(isVisible)
        {
            mopedComponent.SetActive(false);
            isVisible = false;
        }
        else
        {
            mopedComponent.SetActive(true);
            isVisible = true;
        }
    }
}
